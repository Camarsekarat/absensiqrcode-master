<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 2.3.0
    </div>
    <strong> &copy; 2025 <a href="#">Absensi Laptop</a>.</strong>SMK IT NUR HASAN
</footer>