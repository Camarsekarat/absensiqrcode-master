###################
Absensi Karyawan QR Codes
###################
Absensi Karyawan QR Code dibuat dengan Framework CI- 3 
